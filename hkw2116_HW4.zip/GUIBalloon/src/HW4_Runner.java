
import javax.swing.*;


/**
 * @author Helen
 * runner for HW4, calls and creates a JFrame from class frame
 *
 */
public class HW4_Runner {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame myFrame = new Frame();
	}
}
